import argparse

parser=argparse.ArgumentParser()
parser.parse_args()